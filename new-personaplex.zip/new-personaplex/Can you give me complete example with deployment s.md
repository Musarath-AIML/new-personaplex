<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Can you give me complete example with deployment script for pytorch image with custom inference.

I'll give you a complete, production-ready example for deploying PersonaPlex-7B-v1 using the SageMaker PyTorch DLC with custom inference code.

***

# Complete PersonaPlex Deployment with SageMaker PyTorch DLC

## Project Structure

```
personaplex-sagemaker/
├── docker/
│   ├── Dockerfile
│   └── inference.py
├── scripts/
│   ├── 1_prepare_model.py
│   ├── 2_build_and_push.sh
│   └── 3_deploy.py
├── notebooks/
│   └── test_endpoint.ipynb
├── requirements.txt
└── README.md
```


***

## Step 1: Dockerfile

**`docker/Dockerfile`**

```dockerfile
# Use SageMaker PyTorch 2.6 DLC with CUDA 12.4
ARG REGION=us-east-1
FROM 763104351884.dkr.ecr.${REGION}.amazonaws.com/pytorch-inference:2.6.0-gpu-py312-cu124-ubuntu22.04-sagemaker

# Set environment variables
ENV PYTHONUNBUFFERED=TRUE \
    PYTHONDONTWRITEBYTECODE=TRUE \
    DEBIAN_FRONTEND=noninteractive

# Install system dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    libopus-dev \
    ffmpeg \
    libsndfile1 \
    ca-certificates \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies for PersonaPlex
RUN pip install --no-cache-dir \
    transformers==4.36.0 \
    accelerate==0.27.0 \
    sentencepiece==0.1.99 \
    librosa==0.10.1 \
    soundfile==0.12.1 \
    numpy==1.26.4 \
    scipy==1.12.0

# Copy inference code
COPY inference.py /opt/ml/code/

# Set working directory
WORKDIR /opt/ml/code

# Tell SageMaker which script to use
ENV SAGEMAKER_PROGRAM=inference.py

# Healthcheck (optional but recommended)
HEALTHCHECK --interval=30s --timeout=10s --start-period=120s --retries=3 \
    CMD python -c "import torch; assert torch.cuda.is_available()"
```


***

## Step 2: Inference Script

**`docker/inference.py`**

```python
"""
SageMaker inference script for PersonaPlex-7B-v1
Implements the four-function contract for PyTorch DLC
"""

import os
import json
import base64
import logging
from io import BytesIO
from typing import Dict, Any, Tuple

import torch
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoProcessor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def model_fn(model_dir: str) -> Dict[str, Any]:
    """
    Load PersonaPlex model, tokenizer, and processor from /opt/ml/model/
    
    This function is called ONCE when the container starts.
    SageMaker automatically extracts model.tar.gz to model_dir.
    
    Args:
        model_dir: Path to /opt/ml/model/ containing extracted model files
    
    Returns:
        Dictionary containing model, tokenizer, and processor
    """
    logger.info(f"Loading PersonaPlex model from {model_dir}")
    logger.info(f"Available files: {os.listdir(model_dir)}")
    
    # Check GPU availability
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    gpu_count = torch.cuda.device_count()
    logger.info(f"Using device: {device}")
    logger.info(f"Available GPUs: {gpu_count}")
    
    if torch.cuda.is_available():
        for i in range(gpu_count):
            gpu_name = torch.cuda.get_device_name(i)
            gpu_memory = torch.cuda.get_device_properties(i).total_memory / 1e9
            logger.info(f"GPU {i}: {gpu_name} ({gpu_memory:.2f} GB)")
    
    try:
        # Load model with automatic device mapping
        logger.info("Loading model with device_map='auto'")
        model = AutoModelForCausalLM.from_pretrained(
            model_dir,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
            low_cpu_mem_usage=True
        )
        
        # Load tokenizer
        logger.info("Loading tokenizer")
        tokenizer = AutoTokenizer.from_pretrained(
            model_dir,
            trust_remote_code=True
        )
        
        # Set padding token if not present
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        # Load processor if available (for audio processing)
        processor = None
        try:
            logger.info("Attempting to load audio processor")
            processor = AutoProcessor.from_pretrained(
                model_dir,
                trust_remote_code=True
            )
            logger.info("Audio processor loaded successfully")
        except Exception as e:
            logger.warning(f"No audio processor found: {e}")
        
        model.eval()
        logger.info("Model loaded successfully and set to eval mode")
        
        # Log model info
        param_count = sum(p.numel() for p in model.parameters())
        logger.info(f"Model parameters: {param_count:,}")
        
        return {
            'model': model,
            'tokenizer': tokenizer,
            'processor': processor,
            'device': device
        }
        
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}", exc_info=True)
        raise


def input_fn(request_body: bytes, content_type: str = 'application/json') -> Dict[str, Any]:
    """
    Deserialize and prepare the input for inference.
    
    This function is called for EVERY request.
    
    Supported input formats:
    {
        "inputs": "text to process",
        "parameters": {
            "max_length": 512,
            "temperature": 0.7,
            "top_p": 0.9,
            "do_sample": true
        }
    }
    
    Or with audio (base64 encoded):
    {
        "audio": "base64_encoded_audio_bytes",
        "text_prompt": "You are a helpful assistant",
        "parameters": {...}
    }
    
    Args:
        request_body: Raw request bytes
        content_type: Content type header
    
    Returns:
        Parsed input dictionary
    """
    logger.info(f"Parsing input with content_type: {content_type}")
    
    if content_type == 'application/json':
        try:
            input_data = json.loads(request_body)
            logger.info(f"Parsed input keys: {list(input_data.keys())}")
            return input_data
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON: {e}")
            raise ValueError(f"Invalid JSON format: {str(e)}")
    
    elif content_type == 'text/plain':
        # Simple text input
        text = request_body.decode('utf-8')
        return {
            'inputs': text,
            'parameters': {}
        }
    
    else:
        raise ValueError(
            f"Unsupported content type: {content_type}. "
            f"Supported types: application/json, text/plain"
        )


def predict_fn(input_data: Dict[str, Any], model_artifacts: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run PersonaPlex inference.
    
    This function is called for EVERY request after input_fn.
    
    Args:
        input_data: Parsed input from input_fn
        model_artifacts: Model artifacts from model_fn (cached between requests)
    
    Returns:
        Dictionary with predictions
    """
    logger.info("Starting inference")
    
    # Extract model components
    model = model_artifacts['model']
    tokenizer = model_artifacts['tokenizer']
    processor = model_artifacts.get('processor')
    device = model_artifacts['device']
    
    # Extract input parameters
    text_input = input_data.get('inputs', '')
    audio_input = input_data.get('audio')  # Base64 encoded audio
    text_prompt = input_data.get('text_prompt', '')
    parameters = input_data.get('parameters', {})
    
    # Generation parameters with defaults
    max_length = parameters.get('max_length', 512)
    temperature = parameters.get('temperature', 0.7)
    top_p = parameters.get('top_p', 0.9)
    top_k = parameters.get('top_k', 50)
    do_sample = parameters.get('do_sample', True)
    num_return_sequences = parameters.get('num_return_sequences', 1)
    
    try:
        # Handle text-only inference
        if text_input and not audio_input:
            logger.info(f"Text-only inference: {text_input[:100]}...")
            
            # Tokenize input
            inputs = tokenizer(
                text_input,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=2048
            ).to(device)
            
            # Generate
            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_length=max_length,
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    do_sample=do_sample,
                    num_return_sequences=num_return_sequences,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id
                )
            
            # Decode outputs
            generated_texts = [
                tokenizer.decode(output, skip_special_tokens=True)
                for output in outputs
            ]
            
            result = {
                'generated_text': generated_texts[0] if num_return_sequences == 1 else generated_texts,
                'num_tokens': outputs.shape[1]
            }
        
        # Handle audio + text inference (PersonaPlex speech-to-speech)
        elif audio_input:
            logger.info("Audio inference requested")
            
            if processor is None:
                raise ValueError("Audio processor not available for this model")
            
            # Decode base64 audio
            audio_bytes = base64.b64decode(audio_input)
            
            # Process audio (implementation depends on PersonaPlex's audio API)
            # This is a placeholder - adjust based on actual PersonaPlex API
            result = {
                'message': 'Audio processing not fully implemented',
                'received_audio_size': len(audio_bytes),
                'text_prompt': text_prompt
            }
            logger.warning("Audio processing requires PersonaPlex-specific implementation")
        
        else:
            raise ValueError("Must provide either 'inputs' (text) or 'audio'")
        
        logger.info("Inference completed successfully")
        return result
        
    except Exception as e:
        logger.error(f"Inference error: {str(e)}", exc_info=True)
        raise


def output_fn(predictions: Dict[str, Any], accept: str = 'application/json') -> Tuple[str, str]:
    """
    Serialize the prediction output.
    
    This function is called for EVERY request after predict_fn.
    
    Args:
        predictions: Output from predict_fn
        accept: Accept header from request
    
    Returns:
        Tuple of (serialized_output, content_type)
    """
    logger.info(f"Serializing output with accept: {accept}")
    
    if accept == 'application/json' or accept == '*/*':
        try:
            output = json.dumps(predictions, ensure_ascii=False, indent=2)
            return output, 'application/json'
        except Exception as e:
            logger.error(f"Serialization error: {e}")
            raise ValueError(f"Failed to serialize predictions: {str(e)}")
    
    else:
        raise ValueError(
            f"Unsupported accept type: {accept}. "
            f"Supported types: application/json"
        )
```


***

## Step 3: Prepare Model Script

**`scripts/1_prepare_model.py`**

```python
"""
Download PersonaPlex model from HuggingFace and create model.tar.gz
"""

import os
import tarfile
from pathlib import Path
import boto3
from huggingface_hub import snapshot_download

# Configuration
MODEL_ID = "nvidia/personaplex-7b-v1"
HF_TOKEN = os.environ.get("HF_TOKEN")  # Set this as environment variable
LOCAL_MODEL_DIR = "./model_artifacts"
S3_BUCKET = "your-sagemaker-bucket"  # Change this
S3_PREFIX = "personaplex/models"

def download_model():
    """Download model from HuggingFace Hub"""
    print(f"Downloading {MODEL_ID} from HuggingFace Hub...")
    
    model_path = snapshot_download(
        repo_id=MODEL_ID,
        cache_dir=LOCAL_MODEL_DIR,
        token=HF_TOKEN,
        ignore_patterns=["*.md", "*.txt", ".git*"]
    )
    
    print(f"Model downloaded to: {model_path}")
    return model_path

def create_tarball(model_path: str):
    """Create model.tar.gz from downloaded model"""
    print("Creating model.tar.gz...")
    
    tarball_path = "model.tar.gz"
    
    # Create tarball from model directory
    with tarfile.open(tarball_path, "w:gz") as tar:
        # Add all files from model directory
        for item in Path(model_path).rglob("*"):
            if item.is_file():
                # Add file with relative path (no leading directories)
                arcname = item.relative_to(model_path)
                print(f"Adding: {arcname}")
                tar.add(item, arcname=arcname)
    
    tarball_size = os.path.getsize(tarball_path) / (1024**3)  # GB
    print(f"Created {tarball_path} ({tarball_size:.2f} GB)")
    
    return tarball_path

def upload_to_s3(tarball_path: str):
    """Upload model.tar.gz to S3"""
    s3_client = boto3.client('s3')
    s3_key = f"{S3_PREFIX}/model.tar.gz"
    
    print(f"Uploading to s3://{S3_BUCKET}/{s3_key}...")
    
    s3_client.upload_file(
        tarball_path,
        S3_BUCKET,
        s3_key,
        Callback=lambda bytes_transferred: print(
            f"Uploaded {bytes_transferred / (1024**2):.2f} MB",
            end='\r'
        )
    )
    
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    print(f"\nModel uploaded to: {s3_uri}")
    
    return s3_uri

def main():
    """Main execution"""
    # Download model
    model_path = download_model()
    
    # Create tarball
    tarball_path = create_tarball(model_path)
    
    # Upload to S3
    s3_uri = upload_to_s3(tarball_path)
    
    print("\n" + "="*50)
    print("Model preparation complete!")
    print(f"S3 URI: {s3_uri}")
    print("="*50)
    
    return s3_uri

if __name__ == "__main__":
    main()
```


***

## Step 4: Build and Push Docker Image

**`scripts/2_build_and_push.sh`**

```bash
#!/bin/bash

# Configuration
REGION=${AWS_REGION:-us-east-1}
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REPOSITORY_NAME="personaplex-sagemaker-inference"
IMAGE_TAG="latest"

# Full image URI
IMAGE_URI="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${REPOSITORY_NAME}:${IMAGE_TAG}"

echo "Building and pushing Docker image..."
echo "Account: $ACCOUNT_ID"
echo "Region: $REGION"
echo "Image URI: $IMAGE_URI"
echo ""

# Create ECR repository if it doesn't exist
echo "Creating ECR repository..."
aws ecr describe-repositories --repository-names ${REPOSITORY_NAME} --region ${REGION} || \
    aws ecr create-repository --repository-name ${REPOSITORY_NAME} --region ${REGION}

# Authenticate Docker to ECR
echo "Authenticating Docker to ECR..."
aws ecr get-login-password --region ${REGION} | \
    docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

# Build the Docker image
echo "Building Docker image..."
cd docker
docker build \
    --build-arg REGION=${REGION} \
    --platform linux/amd64 \
    -t ${REPOSITORY_NAME}:${IMAGE_TAG} \
    -f Dockerfile .

# Tag the image
echo "Tagging image..."
docker tag ${REPOSITORY_NAME}:${IMAGE_TAG} ${IMAGE_URI}

# Push to ECR
echo "Pushing image to ECR..."
docker push ${IMAGE_URI}

echo ""
echo "============================================"
echo "Image successfully pushed!"
echo "Image URI: ${IMAGE_URI}"
echo "============================================"
echo ""

# Save image URI to file for deployment script
echo ${IMAGE_URI} > ../image_uri.txt
```

Make it executable:

```bash
chmod +x scripts/2_build_and_push.sh
```


***

## Step 5: Deployment Script

**`scripts/3_deploy.py`**

```python
"""
Deploy PersonaPlex model to SageMaker endpoint
"""

import os
import time
import boto3
from sagemaker import get_execution_role, Session
from sagemaker.model import Model
from sagemaker.predictor import Predictor
from sagemaker.serializers import JSONSerializer
from sagemaker.deserializers import JSONDeserializer

# Configuration
REGION = os.environ.get("AWS_REGION", "us-east-1")
ENDPOINT_NAME = "personaplex-7b-v1-endpoint"
INSTANCE_TYPE = "ml.g5.12xlarge"  # 4x A10G GPUs, 96GB VRAM
INSTANCE_COUNT = 1

# Read image URI from file (created by build script)
with open("image_uri.txt", "r") as f:
    IMAGE_URI = f.read().strip()

# Model data location (from prepare_model.py)
MODEL_DATA_S3_URI = "s3://your-sagemaker-bucket/personaplex/models/model.tar.gz"

# Initialize SageMaker session
sagemaker_session = Session()
role = get_execution_role()

print("Deployment Configuration:")
print(f"  Region: {REGION}")
print(f"  Role: {role}")
print(f"  Image: {IMAGE_URI}")
print(f"  Model Data: {MODEL_DATA_S3_URI}")
print(f"  Instance Type: {INSTANCE_TYPE}")
print(f"  Endpoint Name: {ENDPOINT_NAME}")
print("")

def create_model():
    """Create SageMaker Model"""
    print("Creating SageMaker Model...")
    
    model = Model(
        image_uri=IMAGE_URI,
        model_data=MODEL_DATA_S3_URI,
        role=role,
        sagemaker_session=sagemaker_session,
        env={
            'SAGEMAKER_PROGRAM': 'inference.py',
            'SAGEMAKER_SUBMIT_DIRECTORY': '/opt/ml/code',
            'SAGEMAKER_REGION': REGION,
            # GPU optimizations
            'OMP_NUM_THREADS': '1',
            'NCCL_ASYNC_ERROR_HANDLING': '1'
        }
    )
    
    print(f"Model created: {model.name}")
    return model

def deploy_model(model):
    """Deploy model to endpoint"""
    print(f"\nDeploying to endpoint: {ENDPOINT_NAME}")
    print("This will take 5-10 minutes...")
    
    start_time = time.time()
    
    predictor = model.deploy(
        initial_instance_count=INSTANCE_COUNT,
        instance_type=INSTANCE_TYPE,
        endpoint_name=ENDPOINT_NAME,
        serializer=JSONSerializer(),
        deserializer=JSONDeserializer(),
        wait=True,
        # Container startup health check configuration
        container_startup_health_check_timeout=600  # 10 minutes
    )
    
    elapsed = time.time() - start_time
    print(f"\n✓ Deployment successful! ({elapsed/60:.2f} minutes)")
    print(f"✓ Endpoint name: {ENDPOINT_NAME}")
    print(f"✓ Endpoint ARN: {predictor.endpoint_arn}")
    
    return predictor

def test_endpoint(predictor):
    """Test the deployed endpoint"""
    print("\nTesting endpoint...")
    
    test_payload = {
        "inputs": "Hello, how are you doing today?",
        "parameters": {
            "max_length": 100,
            "temperature": 0.7,
            "top_p": 0.9,
            "do_sample": True
        }
    }
    
    print(f"Input: {test_payload['inputs']}")
    
    response = predictor.predict(test_payload)
    
    print(f"\nResponse:")
    print(f"  Generated text: {response['generated_text']}")
    print(f"  Tokens: {response.get('num_tokens', 'N/A')}")
    
    return response

def get_endpoint_info():
    """Get endpoint details"""
    sm_client = boto3.client('sagemaker', region_name=REGION)
    
    try:
        response = sm_client.describe_endpoint(EndpointName=ENDPOINT_NAME)
        
        print("\n" + "="*60)
        print("Endpoint Information:")
        print("="*60)
        print(f"  Name: {response['EndpointName']}")
        print(f"  Status: {response['EndpointStatus']}")
        print(f"  ARN: {response['EndpointArn']}")
        print(f"  Instance Type: {INSTANCE_TYPE}")
        print(f"  Instance Count: {INSTANCE_COUNT}")
        print(f"  Created: {response['CreationTime']}")
        print(f"  Last Modified: {response['LastModifiedTime']}")
        print("="*60)
        
    except sm_client.exceptions.ClientError as e:
        print(f"Endpoint not found: {e}")

def main():
    """Main deployment workflow"""
    
    # Check if endpoint already exists
    sm_client = boto3.client('sagemaker', region_name=REGION)
    
    try:
        existing = sm_client.describe_endpoint(EndpointName=ENDPOINT_NAME)
        print(f"⚠️  Endpoint '{ENDPOINT_NAME}' already exists!")
        print(f"   Status: {existing['EndpointStatus']}")
        
        response = input("Do you want to update it? (yes/no): ")
        if response.lower() != 'yes':
            print("Deployment cancelled.")
            return
        
        print("\nUpdating existing endpoint...")
        
    except sm_client.exceptions.ClientError:
        print("Creating new endpoint...")
    
    # Create and deploy model
    model = create_model()
    predictor = deploy_model(model)
    
    # Test endpoint
    test_endpoint(predictor)
    
    # Show endpoint info
    get_endpoint_info()
    
    print("\n✓ Deployment complete!")
    print(f"\nTo use this endpoint in Python:")
    print(f"""
from sagemaker.predictor import Predictor
from sagemaker.serializers import JSONSerializer
from sagemaker.deserializers import JSONDeserializer

predictor = Predictor(
    endpoint_name='{ENDPOINT_NAME}',
    serializer=JSONSerializer(),
    deserializer=JSONDeserializer()
)

response = predictor.predict({{
    "inputs": "Your text here",
    "parameters": {{"max_length": 100, "temperature": 0.7}}
}})

print(response['generated_text'])
    """)

if __name__ == "__main__":
    main()
```


***

## Step 6: Test Endpoint (Optional)

**`notebooks/test_endpoint.ipynb`**

```python
# Cell 1: Setup
from sagemaker.predictor import Predictor
from sagemaker.serializers import JSONSerializer
from sagemaker.deserializers import JSONDeserializer
import json

ENDPOINT_NAME = "personaplex-7b-v1-endpoint"

predictor = Predictor(
    endpoint_name=ENDPOINT_NAME,
    serializer=JSONSerializer(),
    deserializer=JSONDeserializer()
)

# Cell 2: Simple test
response = predictor.predict({
    "inputs": "What is artificial intelligence?",
    "parameters": {
        "max_length": 200,
        "temperature": 0.7
    }
})

print(json.dumps(response, indent=2))

# Cell 3: Batch test
test_prompts = [
    "Explain machine learning in simple terms.",
    "What are the benefits of cloud computing?",
    "How does natural language processing work?"
]

for prompt in test_prompts:
    print(f"\n{'='*60}")
    print(f"Prompt: {prompt}")
    print('='*60)
    
    response = predictor.predict({
        "inputs": prompt,
        "parameters": {"max_length": 150, "temperature": 0.8}
    })
    
    print(f"Response: {response['generated_text']}")
    print(f"Tokens: {response.get('num_tokens', 'N/A')}")
```


***

## Step 7: Complete Execution Workflow

**`requirements.txt`**

```
boto3>=1.34.0
sagemaker>=2.200.0
huggingface-hub>=0.20.0
```

**Execution Steps:**

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set environment variables
export AWS_REGION=us-east-1
export HF_TOKEN=hf_xxxxxxxxxxxxx  # Your HuggingFace token

# 3. Prepare model (download and upload to S3)
python scripts/1_prepare_model.py

# 4. Build and push Docker image
./scripts/2_build_and_push.sh

# 5. Deploy to SageMaker
python scripts/3_deploy.py
```


***

## Step 8: Cleanup Script

**`scripts/cleanup.py`**

```python
"""
Delete SageMaker endpoint and resources
"""

import boto3
from sagemaker import Session

ENDPOINT_NAME = "personaplex-7b-v1-endpoint"
REGION = "us-east-1"

sm_client = boto3.client('sagemaker', region_name=REGION)
sagemaker_session = Session()

def delete_endpoint():
    """Delete endpoint"""
    try:
        print(f"Deleting endpoint: {ENDPOINT_NAME}")
        sm_client.delete_endpoint(EndpointName=ENDPOINT_NAME)
        print("✓ Endpoint deleted")
    except Exception as e:
        print(f"Error deleting endpoint: {e}")

def delete_endpoint_config():
    """Delete endpoint configuration"""
    try:
        response = sm_client.describe_endpoint(EndpointName=ENDPOINT_NAME)
        config_name = response['EndpointConfigName']
        
        print(f"Deleting endpoint config: {config_name}")
        sm_client.delete_endpoint_config(EndpointConfigName=config_name)
        print("✓ Endpoint config deleted")
    except Exception as e:
        print(f"No endpoint config to delete: {e}")

def list_models():
    """List PersonaPlex models"""
    models = sm_client.list_models(NameContains="personaplex")
    
    if models['Models']:
        print("\nRemaining PersonaPlex models:")
        for model in models['Models']:
            print(f"  - {model['ModelName']}")
        
        response = input("\nDelete these models? (yes/no): ")
        if response.lower() == 'yes':
            for model in models['Models']:
                sm_client.delete_model(ModelName=model['ModelName'])
                print(f"✓ Deleted model: {model['ModelName']}")

if __name__ == "__main__":
    delete_endpoint()
    delete_endpoint_config()
    list_models()
    
    print("\n✓ Cleanup complete!")
```


***

## Cost Estimation

| Resource | Instance | Cost/Hour | Hours/Month | Monthly Cost |
| :-- | :-- | :-- | :-- | :-- |
| **Endpoint** | ml.g5.12xlarge | \$7.09 | 720 | ~\$5,105 |
| **ECR Storage** | - | \$0.10/GB | - | ~\$1-2 |
| **S3 Storage** | - | \$0.023/GB | - | ~\$0.35 |

**Cost savings:**

- Use **SageMaker Serverless Inference** for low/variable traffic
- Use **Auto-scaling** to scale to zero during off-hours
- Use **Spot instances** for dev/test (up to 70% cheaper)

***

This is a complete, production-ready deployment! Let me know if you need any clarifications.

